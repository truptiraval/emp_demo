package employee.info.demo.EmployeeController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import employee.info.demo.EmployeeModel.Employee;
import employee.info.demo.EmployeeRepo.EmployeeRepo;



@RestController
public class EmployeeController {

	@Autowired
	private EmployeeRepo employeeRepository;

	// =====================for create Emp with department================
	@PostMapping("/saveEmployee")
	public ResponseEntity<Map<String, Object>> saveEmployee(@RequestBody Employee employee) {
		Map<String, Object> response = new HashMap<String, Object>();
		try {

			if (employee.getFirst_name() != "" && employee.getFirst_name() != null) {
				employee.setFirst_name(employee.getFirst_name());
			} else {
				response.put("status", "error");
				response.put("message", "please enter first_name");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
			}
			if (employee.getLast_name() != "" && employee.getLast_name() != null) {
				employee.setLast_name(employee.getLast_name());
			} else {
				response.put("status", "error");
				response.put("message", "please enter last_name");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
			}
			if (employee.getCity() != "" && employee.getCity() != null) {
				employee.setCity(employee.getCity());
			} else {
				response.put("status", "error");
				response.put("message", "Please enter city");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
			}
			if (employee.getDepartment() != "" && employee.getDepartment() != null) {
				employee.setDepartment(employee.getDepartment());
			} else {
				response.put("status", "error");
				response.put("message", "Please enter department");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
			}
			if (employee.getSalary() != 0 && employee.getSalary() != 0.0) {
				employee.setSalary(employee.getSalary());
			} else {
				response.put("status", "error");
				response.put("message", "Please enter salary");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
			}

			employeeRepository.save(employee);
			response.put("status", "ok");
			response.put("message", "Employee successfully saved");
			return new ResponseEntity<>(response, HttpStatus.OK);

		} catch (Exception e) {
			response.put("status", "error");
			response.put("message", "Something went to wrong");
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
	}

	// ===========this api for the update emp for the id  =============
	@PutMapping("/updateEmployee/{id}")
	public ResponseEntity<Map<String, Object>> updateTutorial(@PathVariable("id") String id,
			@RequestBody Employee employee) {
		Optional<Employee> employeedata = employeeRepository.findById(id);
		Map<String, Object> response = new HashMap<String, Object>();
		System.out.println(employeedata);

		try {
			if (employeedata.isEmpty()) {
				response.put("status", "error");
				response.put("message", "Employee not exist");
				return new ResponseEntity<>(response,HttpStatus.NOT_FOUND);

			} else {

				Employee empdata = employeedata.get();
				empdata.setFirst_name(employee.getFirst_name());
				empdata.setLast_name(employee.getLast_name());
				empdata.setAge(employee.getAge());
				empdata.setCity(employee.getCity());
				empdata.setSalary(employee.getSalary());
				empdata.setDepartment(employee.getDepartment());
				employeeRepository.save(empdata);

				response.put("status", "ok");
				response.put("message", "Employee Successfully updated");

				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		} catch (Exception e) {
			response.put("status", "error");
			response.put("message", "Something went to wrong");
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
	}

	// =========== 3. Get max number of employee's which belongs to a particular city.==========
	@PostMapping("/getCityWiseEmployee")
	public ResponseEntity<Map<String, Object>> getTutorialById(@RequestBody Employee employee) {

		Map<String, Object> response = new HashMap<String, Object>();
		if (employee.getCity() != "" && employee.getCity() != null) {
			List<Employee> employeeData = employeeRepository.findByCity(employee.getCity());
			System.out.println("empdata" + employeeData);

			if (employeeData.isEmpty()) {
				response.put("status", "error");
				response.put("message", "Employee Not Found");
				return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);

			} else {
				response.put("status", "ok");
				response.put("data", employeeData);
				return new ResponseEntity<>(response, HttpStatus.OK);
			}
		} else {
			response.put("status", "error");
			response.put("message", "please enter city");
			return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
		}
	}

}
