package employee.info.demo.EmployeeRepo;
import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;

import org.springframework.stereotype.Repository;

import employee.info.demo.EmployeeModel.Employee;


@Repository
public interface EmployeeRepo extends MongoRepository<Employee, String> {

	List<Employee> findByCity(String city);	
	long countByDepartment();
}
